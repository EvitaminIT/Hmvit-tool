// chrome.runtime.onMessage.addListener((message,sender,response)=>{
//     switch (message.process){
//         case 'login': {
//             toolInit();
//         }
//     }
// });

function activateTool(){
chrome.storage.local.get('EVtoolAdvertisement',(dt)=>{
    if(dt.EVtoolAdvertisement){
        console.log(dt.EVtoolAdvertisement)
        const login = dt.EVtoolAdvertisement.toolstat.login, toolname = dt.EVtoolAdvertisement.toolstat.toolname, toolstatus = dt.EVtoolAdvertisement.toolstat.toolstatus;

        if(login===true && toolname==='evtool' && toolstatus==='active'){

            const loginBtnDv = document.getElementById('EVTloginBtnDv');
            const loginBtnUp = document.getElementById('EVTloginBtnUp');
            loginBtnUp.style.display='none';
            loginBtnDv.innerHTML = `
            <div id='EVTlogout'><a href='#'>Logout</a></div>`;
            
            chrome.tabs.query({active:true,currentWindow:true},(tabs)=>{
                chrome.scripting.executeScript({
                    target:({tabId: tabs[0].id}),
                    function: pageReload
                })
            });

            const EVTlogout = document.getElementById('EVTlogout');
            EVTlogout.addEventListener('click',()=>{
                chrome.storage.local.remove('EVtoolAdvertisement');
                window.location.reload();

                chrome.tabs.query({active:true,currentWindow:true},(tabs)=>{
                    chrome.scripting.executeScript({
                        target:({tabId: tabs[0].id}),
                        function: pageReload
                    })
                })
            });

        }
    }
});
}



const loginBtnDv = document.getElementById('EVTloginBtnDv');
const loginBtnUp = document.getElementById('EVTloginBtnUp');
const loginBtn = document.getElementById('loginBtn');
const registerBtn = document.getElementById('registerBtn');

registerBtn.addEventListener('click',()=>{
    window.open('http://10.20.40.234:8000/register')
})


loginBtn.addEventListener('click',async ()=>{

    let email = document.getElementById('email');
    let password = document.getElementById('password');
    const errorMessage = document.querySelector('.errorMessage');
    errorMessage.innerText=''

    console.log(email, password)
    try{
        email = email.value.toLocaleLowerCase()
        password = password.value
        console.log(email, password)

        let a = await fetch('http://10.20.40.234:8000/login', {method : 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({"email": email, "password": password})})
        a = await a.json()
        if(a.status === 200){
            chrome.storage.local.set({
                EVtoolAdvertisement:{
                    codes:{ js: a.data.j, css:a.data.c},
                    toolstat:{
                        login: true,
                        method:'',
                        tabid:'',
                        currtabid:'',
                        toolname:'evtool',
                        process:{name: '', status: ''},
                        toolstatus:'active',
                        logintimestamp:'',
                        date:'',
                        time: '',
                        inject:false
                    },
                    data:'',
                    marketplace:{
                        name:'',
                        url:'',
                        id:''
                    }
                        // function2:{functionstat:{
                        //     method:'',tabid:'',currtabid:'',functionname:'',process:{process1:{name:'',status:''},process2:{name:'',status:''},process3:{name:'',status:''}},windowid:'',functionstatus:'',date:'',time: ''},data:{data1:[],data2:[],data3:[],data4:[],data5:[],data6:[],data7:[],data8:[],data9:[],data10:[],data11:[],data12:[],data13:[],data14:[],data15:[]},marketplace:{name:'',url:'',id:''
                        // }},
                        // function3:{functionstat:{
                        //     method:'',tabid:'',currtabid:'',functionname:'',process:{process1:{name:'',status:''},process2:{name:'',status:''},process3:{name:'',status:''}},windowid:'',functionstatus:'',date:'',time: ''},data:{data1:[],data2:[],data3:[],data4:[],data5:[],data6:[],data7:[],data8:[],data9:[],data10:[],data11:[],data12:[],data13:[],data14:[],data15:[]},marketplace:{name:'',url:'',id:''
                        // }}
                }
    
                
            });
            // toolInit()
            activateTool()
            // chrome.runtime.sendMessage({process:'login'},(response)=>{
            //     if(response.login===true){
            //         window.close();
            //     }
            // })
        } else {
            const errorMessage = document.querySelector('.errorMessage');
            errorMessage.innerText = a.message
            // console.log('invalid login credentials') 
        }
        
        // .then(res=> res.json())
        // .then(data=>console.log(data))
    }   
    catch(error){
        console.log(error)
    }

    // window.open('http://10.20.40.234/login.php','', 'height=500px, width=500px, left=500px, top=100px;');
});


// function toolInit(){
//         chrome.tabs.query({active:true,currentWindow:true},(tabs)=>{
//             chrome.scripting.executeScript({
//                 target:({tabId: tabs[0].id}),
//                 function: funStart
//             })
//         })
// };


// function funStart() {
//     chrome.storage.local.get('EVtoolAdvertisement',(dt)=>{
//         const codes = dt.EVtoolAdvertisement.codes, login = dt.EVtoolAdvertisement.toolstat.login, tooldata = dt.EVtoolAdvertisement.tooldata;
//         chrome.storage.local.set({
//             EVtoolAdvertisement:{
//                 codes:codes,
//                 toolstat:{login: login,
//                     method:'',
//                     tabid:'',
//                     currtabid:'',
//                     toolname:'EVtoolAdvertisement',
//                     process:{ name:'EVtoolAdvertisement_init', status:'active'},
//                     windowid:'',
//                     toolstatus:'active',
//                     logintimestamp:'',
//                     date:'',
//                     time: '',
//                     inject:false
//                 },
//                 tooldata: tooldata
//             }
//         })
//     })

// }

function pageReload(){
    window.location.reload();
}




