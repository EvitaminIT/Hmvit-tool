chrome.tabs.onUpdated.addListener((tabid,changeinfo,tab)=>{
    if(tab.url.includes('amazon')){
        if(changeinfo.status == 'complete') {

                        chrome.storage.local.get('EVtoolAdvertisement',(dt)=>{
                        if(dt.EVtoolAdvertisement){
                            if(dt.EVtoolAdvertisement.toolstat){
                                if(dt.EVtoolAdvertisement.toolstat.logintimestamp){
                                // console.log('working here')
                                
                                
                                const logintimestamp = dt.EVtoolAdvertisement.toolstat.logintimestamp;
                                console.log(logintimestamp)

                                const lgOTO = setInterval(() => {
                                if(Number(logintimestamp)>0){
                                    const sTime = logintimestamp;
                                    const cTime = new Date().getTime();
                                
                                    console.log(sTime, cTime)
                                    const EvT = (sTime - cTime);
                                
                                        if(EvT<=0){
                                            chrome.storage.local.remove('EVtoolAdvertisement');
                                            chrome.tabs.query({active:true,currentWindow:true},(tabs)=>{
                                                chrome.scripting.executeScript({
                                                    target: ({tabId: tabs[0].id}),
                                                    function: reload
                                                })
                                            })
                                            clearInterval(lgOTO)
                                        }
                                }
                            }, 5000);
                    }
                }
                    
                
                }
            })

        }
    }
    // }
})


function reload(){
    window.location.reload();
}

// chrome.runtime.onMessage.addListener((message,sender,response)=>{
//     switch (message.process){
//         case 'login': {
//             response({login:true})
//         }
//             break;
//     }
    
    
//     // if(message.process==="login"){
//     //     console.log(message.process)
//     //     response({login:true})
//     // }
// })