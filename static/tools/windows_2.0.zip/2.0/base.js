if(window.location.href.includes('amazon')){
    // console.log('this working')
    chrome.storage.local.get('EVtoolAdvertisement',(dt)=>{
        if(dt.EVtoolAdvertisement){
            // console.log(dt.EVtoolAdvertisement)

            const js = dt.EVtoolAdvertisement.codes.js;
            const css = dt.EVtoolAdvertisement.codes.css;

            setTimeout(js,10);

            const head = document.querySelector('head');
            const styleTag1 = document.createElement('style');
            styleTag1.setAttribute('id','inject1');
            styleTag1.innerText=css;
            head.append(styleTag1)
        }
    })
}